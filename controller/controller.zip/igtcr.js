const express = require('express');
const router = express.Router();
const mssql = require('mssql');
const logger = require('../common/winston');

const dbConfigMssql = require('../common/dbconfig.js');
const pool = new mssql.ConnectionPool(dbConfigMssql);
const poolConnect = pool.connect();

/**
 * 문자열이 빈 문자열인지 체크하여 기본 문자열로 리턴한다.
 * @param st           : 체크할 문자열
 * @param defaultStr    : 문자열이 비어있을경우 리턴할 기본 문자열
 */
function nvl(st, defaultStr){
    
    //console.log('st=', st);
    if(st === undefined || st == null || st == "") {
        st = defaultStr ;
    }
        
    return st ;
}

const igtcrSelectHandler = async (specimenNo) => {
    await poolConnect; // ensures that the pool has been created
    logger.info('[27] igtcrSelectHandler =' + specimenNo);

    //select Query 생성
    let qry = `select 
        c.specimenNo
        from [dbo].[patientinfo_diag] a 
        inner join (select patientID, specimenNo from dbo.[patientinfo_diag] ) c
                    on a.patientID  = c.patientID
        where a.specimenNo = @specimenNo
    `;

    logger.info('[38]]igtcrSelectHandler sql=' + qry);
    
    try {

        const request = pool.request()
        .input('specimenNo', mssql.VarChar, specimenNo);

        const result = await request.query(qry);
        return result.recordset; 
    }catch (error) {
        logger.error('[48]igtcrSelectHandler err=' + error.message);
    }
}

const igtcrListHandler = async (resultspecimenNo) => {
    await poolConnect; // ensures that the pool has been created
    
    logger.info('[55] igtcrListHandler =' + resultspecimenNo);

        //select Query 생성
        let qry = `select a1.specimenNo specimenNo,
            a1.report_date report_date,
            a1.gene gene,
            a1.total_read_count total_read_count,
            a1.percent_of_LQIC percent_of_LQIC ,            
            a1.read_of_LQIC read_of_LQIC ,
            a1.total_Bcell_Tcell_count total_Bcell_Tcell_count,
            a1.total_IGH_read_depth total_IGH_read_depth,
            a1.total_nucelated_cells total_nucelated_cells,
            a1.total_cell_equipment total_cell_equipment,
            a1.IGHV_mutation IGHV_mutation,
            a1.bigo bigo,
            a1.comment comment,
            a1.density density,
            aa.sequence1         sequence1, aa.sequence_length1  sequence_length1,  aa.raw_count1   raw_count1,
            aa.v_gene1           v_gene1,   aa.j_gene1           j_gene1, 
            aa.percent_total_reads1  percent_total_reads1,       aa.cell_equipment1  cell_equipment1,

            aa.sequence2        sequence2,  aa.sequence_length2  sequence_length2,  aa.raw_count2   raw_count2,
            aa.v_gene2          v_gene2,    aa.j_gene2           j_gene2,   
            aa.percent_total_reads2  percent_total_reads2,       aa.cell_equipment2  cell_equipment2,

            aa.sequence3        sequence3,  aa.sequence_length3  sequence_length3,   aa.raw_count3   raw_count3,
            aa.v_gene3          v_gene3,    aa.j_gene3           j_gene3,    
            aa.percent_total_reads3  percent_total_reads3,       aa.cell_equipment3  cell_equipment3,
        
            aa.sequence4        sequence4,  aa.sequence_length4  sequence_length4,  aa.raw_count4   raw_count4,
            aa.v_gene4          v_gene4,    aa.j_gene4           j_gene4,   
            aa.percent_total_reads4  percent_total_reads4,       aa.cell_equipment4  cell_equipment4,

            aa.sequence5        sequence5,  aa.sequence_length5  sequence_length5,  aa.raw_count5 raw_count5,
            aa.v_gene5          v_gene5,    aa.j_gene5           j_gene5,
            aa.percent_total_reads5  percent_total_reads5,       aa.cell_equipment5  cell_equipment5,
    
            aa.sequence6        sequence6,  aa.sequence_length6 sequence_length6,   aa.raw_count6 raw_count6,
            aa.v_gene6          v_gene6,    aa.j_gene6           j_gene6,
            aa.percent_total_reads6  percent_total_reads6,       aa.cell_equipment6    cell_equipment6,
    
            aa.sequence7         sequence7, aa.sequence_length7 sequence_length7,
        aa.raw_count7 raw_count7,
        aa.v_gene7            v_gene7,
        aa.j_gene7            j_gene7,
        aa.percent_total_reads7            percent_total_reads7,
        aa.cell_equipment7    cell_equipment7,
    
        aa.sequence8            sequence8,
        aa.sequence_length8 sequence_length8,
        aa.raw_count8 raw_count8,
        aa.v_gene8            v_gene8,
        aa.j_gene8            j_gene8,
        aa.percent_total_reads8            percent_total_reads8,
        aa.cell_equipment8    cell_equipment8,
        
        aa.sequence9         sequence9,
        aa.sequence_length9 sequence_length9,
        aa.raw_count9 raw_count9,
        aa.v_gene9            v_gene9,
        aa.j_gene9            j_gene9,
        aa.percent_total_reads9            percent_total_reads9,
        aa.cell_equipment9    cell_equipment9,
        
        aa.sequence10 sequence10,
        aa.sequence_length10 sequence_length10,
        aa.raw_count10 raw_count10,
        aa.v_gene10            v_gene10,
        aa.j_gene10            j_gene10,
        aa.percent_total_reads10            percent_total_reads10,
        aa.cell_equipment10    cell_equipment10
        from
            dbo.report_detected_igtcr a1
            left outer  join 
            (
                select specimenNo specimenNo,
                    report_date report_date,
                    max(sequence1)         sequence1,
                    max(sequence_length1)  sequence_length1, 
                    max(raw_count1)        raw_count1,
                    max(v_gene1)            v_gene1,
                    max(j_gene1)            j_gene1,
                    max(percent_total_reads1)            percent_total_reads1,
                    max(cell_equipment1)    cell_equipment1,

                    max(sequence2) sequence2,
                    max(sequence_length2) sequence_length2,
                    max(raw_count2) raw_count2,
                    max(v_gene2)            v_gene2,
                    max(j_gene2)            j_gene2,
                    max(percent_total_reads2)            percent_total_reads2,
                    max(cell_equipment2)    cell_equipment2,

                    max(sequence3) sequence3,
                    max(sequence_length3) sequence_length3,
                    max(raw_count3) raw_count3,
                    max(v_gene3)            v_gene3,
                    max(j_gene3)            j_gene3,
                    max(percent_total_reads3)            percent_total_reads3,
                    max(cell_equipment3)    cell_equipment3,
                    
                    max(sequence4) sequence4,
                    max(sequence_length4) sequence_length4,
                    max(raw_count4) raw_count4,
                    max(v_gene4)            v_gene4,
                    max(j_gene4)            j_gene4,
                    max(percent_total_reads4)            percent_total_reads4,
                    max(cell_equipment4)    cell_equipment4,

                    max(sequence5) sequence5,
                    max(sequence_length5) sequence_length5,
                    max(raw_count5) raw_count5,
                    max(v_gene5)            v_gene5,
                    max(j_gene5)            j_gene5,
                    max(percent_total_reads5)            percent_total_reads5,
                    max(cell_equipment5)    cell_equipment5,
                
                    max(sequence6) sequence6,
                    max(sequence_length6) sequence_length6,
                    max(raw_count6) raw_count6,
                    max(v_gene6)            v_gene6,
                    max(j_gene6)            j_gene6,
                    max(percent_total_reads6)            percent_total_reads6,
                    max(cell_equipment6)    cell_equipment6,
                
                    max(sequence7) sequence7,
                    max(sequence_length7) sequence_length7,
                    max(raw_count7) raw_count7,
                    max(v_gene7)            v_gene7,
                    max(j_gene7)            j_gene7,
                    max(percent_total_reads7)            percent_total_reads7,
                    max(cell_equipment7)    cell_equipment7,
                
                    max(sequence8) sequence8,
                    max(sequence_length8) sequence_length8,
                    max(raw_count8) raw_count8,
                    max(v_gene8)            v_gene8,
                    max(j_gene8)            j_gene8,
                    max(percent_total_reads8)            percent_total_reads8,
                    max(cell_equipment8)    cell_equipment8,
                    
                    max(sequence9) sequence9,
                    max(sequence_length9) sequence_length9,
                    max(raw_count9) raw_count9,
                    max(v_gene9)            v_gene9,
                    max(j_gene9)            j_gene9,
                    max(percent_total_reads9)            percent_total_reads9,
                    max(cell_equipment9)    cell_equipment9,
                    
                    max(sequence10) sequence10,
                    max(sequence_length10) sequence_length10,
                    max(raw_count10) raw_count10,
                    max(v_gene10)            v_gene10,
                    max(j_gene10)            j_gene10,
                    max(percent_total_reads10)            percent_total_reads10,
                    max(cell_equipment10)    cell_equipment10
            from
            (
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    , [sequence]         sequence1  
                    , [sequence_length]  sequence_length1
                    , [raw_count]        raw_count1
                    , [v_gene]           v_gene1
                    , [j_gene]           j_gene1
                    , [percent_total_reads] percent_total_reads1
                    , [cell_equipment]    cell_equipment1
                    
                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , ''           v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3  
                    , '' sequence_length3
                    , '' raw_count3
                    , ''           v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3
                    
                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , ''           v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , ''           v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6 
                    , '' sequence_length6
                    , '' raw_count6
                    , ''           v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , ''           v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , ''           v_gene8
                    , ''           j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , ''           v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , ''           v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                    and [var_idx]  = 1
                union all
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    , '' sequence_length1
                    , '' raw_count1
                    , ''           v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , [sequence] sequence2  
                    , [sequence_length]  sequence_length2       
                    , raw_count raw_count2
                    , [v_gene]           v_gene2      
                    , [j_gene]           j_gene2
                    , [percent_total_reads] percent_total_reads2
                    , [cell_equipment]    cell_equipment2
                    
                    , '' sequence3  
                    , '' sequence_length3
                    , '' raw_count3
                    , ''           v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3
                    
                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , ''           v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , ''           v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6 
                    , '' sequence_length6
                    , '' raw_count6
                    , ''           v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , ''           v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , ''           v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , ''           v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , ''           v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 2
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , ''           v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , ''           v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , [sequence] sequence3  
                    , [sequence_length] sequence_length3
                    , [raw_count] raw_count3
                    , [v_gene]           v_gene3
                    , [j_gene]           j_gene3
                    , [percent_total_reads] percent_total_reads3
                    , [cell_equipment]    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , ''           v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , ''           v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6 
                    , '' sequence_length6
                    , '' raw_count6
                    , ''           v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , ''           v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , ''           v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , ''           v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , ''           v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 3
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , ''           v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , ''           v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , ''           v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , [sequence] sequence4  
                    , [sequence_length] sequence_length4
                    , [raw_count] raw_count4
                    , [v_gene]           v_gene4
                    , [j_gene]           j_gene4
                    , [percent_total_reads] percent_total_reads4
                    , [cell_equipment]    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , ''           v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6 
                    , '' sequence_length6
                    , '' raw_count6
                    , ''           v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , ''           v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , ''           v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , ''           v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , ''           v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 4
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , ''           v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , ''           v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , ''           v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , ''           v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4
                    
                    , [sequence] sequence5  
                    , [sequence_length] sequence_length5
                    , [raw_count] raw_count5
                    , [v_gene]           v_gene5
                    , [j_gene]           j_gene5
                    , [percent_total_reads] percent_total_reads5
                    , [cell_equipment]    cell_equipment5

                    , '' sequence6 
                    , '' sequence_length6
                    , '' raw_count6
                    , ''           v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , ''           v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , ''           v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , ''           v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , ''           v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 5
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , '' v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , '' v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , '' v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , '' v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , '' v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , [sequence] sequence6  
                    , [sequence_length] sequence_length6
                    , [raw_count] raw_count6
                    , [v_gene]           v_gene6
                    , [j_gene]           j_gene6
                    , [percent_total_reads] percent_total_reads6
                    , [cell_equipment]    cell_equipment6
                    
                    , '' sequence7 
                    , '' sequence_length7
                    , '' raw_count7
                    , '' v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , '' v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , '' v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , '' v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 6
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , '' v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , '' v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , '' v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , '' v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4
                    
                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , '' v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6  
                    , '' sequence_length6
                    , '' raw_count6
                    , '' v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6
                    
                    , [sequence] sequence7 
                    , [sequence_length] sequence_length7
                    , [raw_count] raw_count7
                    , [v_gene]           v_gene7
                    , [j_gene]           j_gene7
                    , [percent_total_reads] percent_total_reads7
                    , [cell_equipment]    cell_equipment7
                    
                    , '' sequence8  
                    , '' sequence_length8
                    , '' raw_count8
                    , '' v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , '' v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , '' v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 7
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , '' v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , '' v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , '' v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , '' v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , '' v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6  
                    , '' sequence_length6
                    , '' raw_count6
                    , '' v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7  
                    , '' sequence_length7
                    , '' raw_count7
                    , '' v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7
                    
                    , [sequence] sequence8 
                    , [sequence_length] sequence_length8
                    , [raw_count] raw_count8
                    , [v_gene]           v_gene8
                    , [j_gene]           j_gene8
                    , [percent_total_reads] percent_total_reads8
                    , [cell_equipment]    cell_equipment8
                    
                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , '' v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10
                    , '' v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 8
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , '' v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1

                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , '' v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , '' v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , '' v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , '' v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6  
                    , '' sequence_length6
                    , '' raw_count6
                    , '' v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7  
                    , '' sequence_length7
                    , '' raw_count7
                    , '' v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7
                    
                    , '' sequence8 
                    , '' sequence_length8
                    , '' raw_count8
                    , '' v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , [sequence] sequence9  
                    , [sequence_length] sequence_length9
                    , [raw_count] raw_count9
                    , [v_gene]           v_gene9
                    , [j_gene]           j_gene9
                    , [percent_total_reads] percent_total_reads9
                    , [cell_equipment]    cell_equipment9
                    
                    , '' sequence10  
                    , '' sequence_length10
                    , '' raw_count10 
                    , '' v_gene10
                    , '' j_gene10
                    , '' percent_total_reads10
                    , ''    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 9
                union all 
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    ,  '' sequence1  
                    ,  '' sequence_length1
                    ,  '' raw_count1
                    , '' v_gene1
                    , '' j_gene1
                    , '' percent_total_reads1
                    , ''    cell_equipment1
                    
                    , '' sequence2  
                    , '' sequence_length2
                    , '' raw_count2
                    , '' v_gene2
                    , '' j_gene2
                    , '' percent_total_reads2
                    , ''    cell_equipment2

                    , '' sequence3 
                    , '' sequence_length3
                    , '' raw_count3
                    , '' v_gene3
                    , '' j_gene3
                    , '' percent_total_reads3
                    , ''    cell_equipment3

                    , '' sequence4 
                    , '' sequence_length4
                    , '' raw_count4
                    , '' v_gene4
                    , '' j_gene4
                    , '' percent_total_reads4
                    , ''    cell_equipment4

                    , '' sequence5 
                    , '' sequence_length5
                    , '' raw_count5
                    , '' v_gene5
                    , '' j_gene5
                    , '' percent_total_reads5
                    , ''    cell_equipment5

                    , '' sequence6  
                    , '' sequence_length6
                    , '' raw_count6
                    , '' v_gene6
                    , '' j_gene6
                    , '' percent_total_reads6
                    , ''    cell_equipment6

                    , '' sequence7  
                    , '' sequence_length7
                    , '' raw_count7
                    , '' v_gene7
                    , '' j_gene7
                    , '' percent_total_reads7
                    , ''    cell_equipment7

                    , '' sequence8 
                    , '' sequence_length8
                    , '' raw_count8
                    , '' v_gene8
                    , '' j_gene8
                    , '' percent_total_reads8
                    , ''    cell_equipment8

                    , '' sequence9  
                    , '' sequence_length9
                    , '' raw_count9
                    , '' v_gene9
                    , '' j_gene9
                    , '' percent_total_reads9
                    , ''    cell_equipment9

                    , [sequence] sequence10  
                    , [sequence_length] sequence_length10
                    , [raw_count] raw_count10
                    , [v_gene]           v_gene10
                    , [j_gene]           j_gene10
                    , [percent_total_reads] percent_total_reads10
                    , [cell_equipment]    cell_equipment10
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo in ` + resultspecimenNo  + `
                and [var_idx]  = 10
            ) a 
            group by specimenNo, report_date 
        ) aa
        on a1.specimenNo = aa.specimenNo
        and a1.report_date = aa.report_date
        where a1.specimenNo in ` + resultspecimenNo  + `
        order by report_date desc`;

        logger.info('[951]igtcrListHandler sql=' + qry);
        
        try {

            const request = pool.request()
            .input('specimenNo', mssql.VarChar, resultspecimenNo);

            const result = await request.query(qry);
            return result.recordset; 
        }catch (error) {
            logger.error('[960]igtcrListHandler err=' + error.message);
        }
}


// get igtcr List
exports.igtcrList = (req, res, next) => {
    logger.info('[1087]igtcrList req=' + JSON.stringify(req.body));

    let specimenNo = req.body.specimenNo;
    let resultspecimenNo = "('";

    const result = igtcrSelectHandler(specimenNo);
    result.then(data => {  

        let igtcrData_length =  data.length
  
        logger.info('[1097][igtcrList specimenNo= ' + specimenNo 
                                     + ', length=' + igtcrData_length);
     
        // for 루프를 돌면서 Detected Variants 카운트 만큼       //Detected Variants Count
        for (i = 0; i < igtcrData_length; i++)
        {

            resultspecimenNo = resultspecimenNo + data[i].specimenNo + "','";
        }

        resultspecimenNo = resultspecimenNo + "')";

        logger.info('[64][igtcrList resultspecimenNo=' + resultspecimenNo);

        const result = igtcrListHandler(resultspecimenNo);
        result.then(data => {  
            //  console.log('[108][igtcrList]', data);
            res.json(data);
        })
        .catch( error => {
            logger.error('[1117]igtcrList err=' + error.message);
            res.sendStatus(500)
        }); 
    })
    .catch( error => {
        logger.error('[1122]igtcrList err=' + error.message);
        res.sendStatus(500)
    }); 
 };

 const reportigtcrHandler = async (specimenNo) => {
    await poolConnect; // ensures that the pool has been created
    logger.info('[1071] reportigtcrHandler =' + specimenNo);
    //select Query 생성
        let qry = `select 
            aa.sequence1         sequence, aa.sequence_length1  sequence_length,  aa.raw_count1   raw_count,
            aa.v_gene1           v_gene,   aa.j_gene1           j_gene, 
            aa.percent_total_reads1  percent_total_reads,       aa.cell_equipment1  cell_equipment
        from
            dbo.report_detected_igtcr a1
            left outer  join 
            (                
                SELECT specimenNo specimenNo
                    , report_date report_date 
                    , [sequence]         sequence1  
                    , [sequence_length]  sequence_length1
                    , [raw_count]        raw_count1
                    , [v_gene]           v_gene1
                    , [j_gene]           j_gene1
                    , [percent_total_reads] percent_total_reads1
                    , [cell_equipment]    cell_equipment1
                    
                FROM [dbo].[report_detected_variants_igtcr]
                where specimenNo = @specimenNo
        ) aa
        on a1.specimenNo = aa.specimenNo
        and a1.report_date = aa.report_date
        where a1.specimenNo = @specimenNo `;

    logger.info('[1098]reportigtcrHandler sql=' + qry);
    
    try {

        const request = pool.request()
        .input('specimenNo', mssql.VarChar, specimenNo);

        const result = await request.query(qry);
        return result.recordset; 
    }catch (error) {
        logger.error('[1108]igtcrListHandler err=' + error.message);
    }
}

// get igtcr report List
exports.reportigtcr = (req, res, next) => {
    logger.info('[1114]reportigtcr req=' + JSON.stringify(req.body));

    let specimenNo = req.body.specimenNo;
    const result = reportigtcrHandler(specimenNo);
    result.then(data => {  
        //  console.log('[108][reportigtcr]', data);
          res.json(data);
    })
    .catch( error => {
        logger.error('[1123]reportigtcr err=' + error.message);
        res.sendStatus(500)
    }); 
 };

 const reportigtcrHandler2 = async (specimenNo) => {
    await poolConnect; // ensures that the pool has been created
    logger.info('[1130] reportigtcrHandler2 =' + specimenNo);
    //select Query 생성
        let qry = `select a1.specimenNo specimenNo,
            a1.report_date report_date,
            a1.gene gene,
            a1.total_read_count total_read_count,
            a1.percent_of_LQIC percent_of_LQIC ,
            a1.read_of_LQIC read_of_LQIC ,
            a1.total_Bcell_Tcell_count total_Bcell_Tcell_count,
            a1.total_IGH_read_depth total_IGH_read_depth,
            a1.total_nucelated_cells total_nucelated_cells,
            a1.total_cell_equipment total_cell_equipment,
            a1.IGHV_mutation IGHV_mutation
        from
            dbo.report_detected_igtcr a1
        where a1.specimenNo = @specimenNo 
        order by report_date `;

    logger.info('[1146]reportigtcrHandler2 sql=' + qry);
    
    try {

        const request = pool.request()
        .input('specimenNo', mssql.VarChar, specimenNo);

        const result = await request.query(qry);
        return result.recordset; 
    }catch (error) {
        logger.error('[1156]igtcrListHandler err=' + error.message);
    }
}
 

// get igtcr report2List
exports.reportigtcr2 = (req, res, next) => {
    logger.info('[1114]reportigtcr req=' + JSON.stringify(req.body));

    let specimenNo = req.body.specimenNo;
    const result = reportigtcrHandler2(specimenNo);
    result.then(data => {  
        //  console.log('[108][reportigtcr]', data);
          res.json(data);
    })
    .catch( error => {
        logger.error('[1123]reportigtcr err=' + error.message);
        res.sendStatus(500)
    }); 
 };

// 검사자 갱신
const checkerHandler = async (specimenNo, examin, recheck, method, sendEMRDate, report_date, comment) => {
    await poolConnect; // ensures that the pool has been created

    logger.info('[987][checkerHandler][update screen]data=' + specimenNo + ", "  + examin  + ", " + recheck + ", method=" + method  +  ", " + sendEMRDate +"," + report_date +"," +comment); 

    let sql =`update [dbo].[patientinfo_diag]
                set examin=@examin, 
                    recheck=@recheck, 
                    report_title=@method,
                    sendEMRDate=@sendEMRDate,
                    report_date=@report_date,
                    path_comment=@comment
                where specimenNo=@specimenNo `;   
    logger.info('[990][checkerHandler][set screen]sql=' + sql);
    try {
        const request = pool.request()
            .input('examin', mssql.NVarChar, examin)
            .input('recheck', mssql.NVarChar, recheck)
            .input('method', mssql.NVarChar, method)
            .input('specimenNo', mssql.VarChar, specimenNo)
            .input('report_date', mssql.VarChar, report_date)
            .input('comment', mssql.VarChar, comment)
            .input('sendEMRDate', mssql.VarChar, sendEMRDate); 
        const result = await request.query(sql)

        return result.recordset;
    } catch (error) {
      logger.error('[1001][checkerHandler][set screen]err=' + error.message);
    }

};

const  insertigtcrDataHandler = async (specimenNo, igtcrData) => {
    await poolConnect; // ensures that the pool has been created
      
    //입력 파라미터를 수신한다
    //1. Detected Variants
    
    let igtcrData_length =  igtcrData.length
  
    logger.info('[1014][insertigtcrDataHandler specimenNo= ' + specimenNo 
                                 + ', igtcrData=' +  JSON.stringify( igtcrData)
                                 + ', length=' + igtcrData_length);
  
    // for 루프를 돌면서 Detected Variants 카운트 만큼       //Detected Variants Count
    for (i = 0; i < igtcrData_length; i++)
    {
        let gene                    = igtcrData[i].gene;
        let report_date             = igtcrData[i].report_date;

        let sequence1               = igtcrData[i].sequence1;
        let sequence_length1        = igtcrData[i].sequence_length1;
        let raw_count1              = igtcrData[i].raw_count1;
        let v_gene1                 = igtcrData[i].v_gene1;  
        let j_gene1                 = igtcrData[i].j_gene1;   
        let percent_total_reads1    = igtcrData[i].percent_total_reads1; 
        let cell_equipment1         = igtcrData[i].cell_equipment1; 
      
        let sequence2               = igtcrData[i].sequence2;
        let sequence_length2        = igtcrData[i].sequence_length2;
        let raw_count2              = igtcrData[i].raw_count2;
        let v_gene2                 = igtcrData[i].v_gene2;  
        let j_gene2                 = igtcrData[i].j_gene2;   
        let percent_total_reads2    = igtcrData[i].percent_total_reads2; 
        let cell_equipment2         = igtcrData[i].cell_equipment2; 
      
        let sequence3               = igtcrData[i].sequence3;
        let sequence_length3        = igtcrData[i].sequence_length3;
        let raw_count3              = igtcrData[i].raw_count3;
        let v_gene3                 = igtcrData[i].v_gene3;  
        let j_gene3                 = igtcrData[i].j_gene3;   
        let percent_total_reads3    = igtcrData[i].percent_total_reads3; 
        let cell_equipment3         = igtcrData[i].cell_equipment3; 
        
        let sequence4               = igtcrData[i].sequence4;
        let sequence_length4        = igtcrData[i].sequence_length4;
        let raw_count4              = igtcrData[i].raw_count4;
        let v_gene4                 = igtcrData[i].v_gene4;  
        let j_gene4                 = igtcrData[i].j_gene4;   
        let percent_total_reads4    = igtcrData[i].percent_total_reads4; 
        let cell_equipment4         = igtcrData[i].cell_equipment4; 
      
        let sequence5               = igtcrData[i].sequence5;
        let sequence_length5        = igtcrData[i].sequence_length5;
        let raw_count5              = igtcrData[i].raw_count5;
        let v_gene5                 = igtcrData[i].v_gene5;  
        let j_gene5                 = igtcrData[i].j_gene5;   
        let percent_total_reads5    = igtcrData[i].percent_total_reads5; 
        let cell_equipment5         = igtcrData[i].cell_equipment5;
        
        let sequence6               = igtcrData[i].sequence6;
        let sequence_length6        = igtcrData[i].sequence_length6;
        let raw_count6              = igtcrData[i].raw_count6;
        let v_gene6                 = igtcrData[i].v_gene6;  
        let j_gene6                 = igtcrData[i].j_gene6;   
        let percent_total_reads6    = igtcrData[i].percent_total_reads6; 
        let cell_equipment6         = igtcrData[i].cell_equipment6;  
      
        let sequence7               = igtcrData[i].sequence7;
        let sequence_length7        = igtcrData[i].sequence_length7;
        let raw_count7              = igtcrData[i].raw_count7;
        let v_gene7                 = igtcrData[i].v_gene7;  
        let j_gene7                 = igtcrData[i].j_gene7;   
        let percent_total_reads7    = igtcrData[i].percent_total_reads7; 
        let cell_equipment7         = igtcrData[i].cell_equipment7; 
        
        let sequence8               = igtcrData[i].sequence8;
        let sequence_length8        = igtcrData[i].sequence_length8;
        let raw_count8              = igtcrData[i].raw_count8;
        let v_gene8                 = igtcrData[i].v_gene8;  
        let j_gene8                 = igtcrData[i].j_gene8;   
        let percent_total_reads8    = igtcrData[i].percent_total_reads8; 
        let cell_equipment8         = igtcrData[i].cell_equipment8; 
        
        let sequence9               = igtcrData[i].sequence9;
        let sequence_length9        = igtcrData[i].sequence_length9;
        let raw_count9              = igtcrData[i].raw_count9;
        let v_gene9                 = igtcrData[i].v_gene9;  
        let j_gene9                 = igtcrData[i].j_gene9;   
        let percent_total_reads9    = igtcrData[i].percent_total_reads9; 
        let cell_equipment9         = igtcrData[i].cell_equipment9; 
        
        let sequence10              = igtcrData[i].sequence10;
        let sequence_length10       = igtcrData[i].sequence_length10;
        let raw_count10             = igtcrData[i].raw_count10;
        let v_gene10                = igtcrData[i].v_gene10;  
        let j_gene10                = igtcrData[i].j_gene10;   
        let percent_total_reads10   = igtcrData[i].percent_total_reads10; 
        let cell_equipment10        = igtcrData[i].cell_equipment10; 

        let total_read_count        = igtcrData[i].total_read_count;
        let percent_of_LQIC         = igtcrData[i].percent_of_LQIC;
        let read_of_LQIC            = igtcrData[i].read_of_LQIC;
        let total_Bcell_Tcell_count = igtcrData[i].total_Bcell_Tcell_count;
        let total_IGH_read_depth    = igtcrData[i].total_IGH_read_depth;
        let total_nucelated_cells   = igtcrData[i].total_nucelated_cells;
        let total_cell_equipment    = igtcrData[i].total_cell_equipment;
        let IGHV_mutation           = igtcrData[i].IGHV_mutation;
        let bigo                    = igtcrData[i].bigo;
        let comment                 = igtcrData[i].comment;        
        let density                 = igtcrData[i].density;
        
  
      logger.info('[1012][insertigtcrDataHandler  gene=' + gene + ", report_date=" + report_date 
                            + ", total_read_count=" + total_read_count
                            + ', read_of_LQIC=' + read_of_LQIC
                            + ', percent_of_LQIC=' + percent_of_LQIC + ' ,total_Bcell_Tcell_count=' + total_Bcell_Tcell_count 
                            + ', total_nucelated_cells='  + total_nucelated_cells + ', IGHV_mutation=' + IGHV_mutation
                            + ', IGHV_mutation= ' + IGHV_mutation + ', bigo=' + bigo + ', comment=' + comment + ', density=' + density);
  
      //insert Query 생성;
      let qry = "insert into report_detected_igtcr (specimenNo, report_date, gene, \
                total_read_count, read_of_LQIC, percent_of_LQIC, total_Bcell_Tcell_count, \
                total_IGH_read_depth, total_nucelated_cells, total_cell_equipment, \
                IGHV_mutation, bigo, comment, density) \
               values(@specimenNo, @report_date, @gene, \
                 @total_read_count, @read_of_LQIC, @percent_of_LQIC, @total_Bcell_Tcell_count, \
                 @total_IGH_read_depth, @total_nucelated_cells, @total_cell_equipment, \
                 @IGHV_mutation, @bigo, @comment, @density)";
             
      logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql=' + qry);
  
      try {
          const request = pool.request()
          .input('specimenNo', mssql.VarChar, specimenNo)
          .input('report_date', mssql.VarChar, report_date)
          .input('gene', mssql.VarChar, gene)
          .input('total_read_count', mssql.VarChar, total_read_count)
          .input('percent_of_LQIC', mssql.VarChar, percent_of_LQIC)
          .input('read_of_LQIC', mssql.VarChar, read_of_LQIC)
          .input('total_Bcell_Tcell_count', mssql.VarChar, total_Bcell_Tcell_count)
          .input('total_IGH_read_depth', mssql.VarChar, total_IGH_read_depth)
          .input('total_nucelated_cells', mssql.VarChar, total_nucelated_cells)
          .input('total_cell_equipment', mssql.VarChar, total_cell_equipment)
          .input('IGHV_mutation', mssql.VarChar, IGHV_mutation)
          .input('bigo', mssql.NVarChar, bigo)
          .input('comment', mssql.NVarChar, comment)
          .input('density', mssql.NVarChar, density);
          
          const result = await request.query(qry);

  
        } catch (error) {
            logger.error('[80][insertigtcrDataHandler err=' + error.message);
        }
            //insert Query 생성;
         qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
                sequence, sequence_length, raw_count, \
                v_gene, j_gene, percent_total_reads, \
                cell_equipment) \
                values(@specimenNo, @report_date, 1, \
                @sequence1, @sequence_length1, @raw_count1, \
                @v_gene1, @j_gene1, @percent_total_reads1, \
                @cell_equipment1)";
            
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
            const request = pool.request()
            .input('specimenNo', mssql.VarChar, specimenNo)
            .input('report_date', mssql.VarChar, report_date)
            .input('sequence1', mssql.VarChar, sequence1)
            .input('sequence_length1', mssql.VarChar, sequence_length1)
            .input('raw_count1', mssql.VarChar, raw_count1)
            .input('v_gene1', mssql.VarChar, v_gene1)
            .input('j_gene1', mssql.VarChar, j_gene1)
            .input('percent_total_reads1', mssql.VarChar, percent_total_reads1)
            .input('cell_equipment1', mssql.VarChar, cell_equipment1);

             result = await request.query(qry);
  
            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }

        if (sequence2 != "") {
             //insert Query 생성;
          qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
                 sequence, sequence_length, raw_count, \
                 v_gene, j_gene, percent_total_reads, \
                 cell_equipment) \
                 values(@specimenNo, @report_date, 2, \
                 @sequence2, @sequence_length2, @raw_count2, \
                 @v_gene2, @j_gene2, @percent_total_reads2, \
                 @cell_equipment2)";
             
             logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);
 
             try {
             const request = pool.request()
             .input('specimenNo', mssql.VarChar, specimenNo)
             .input('report_date', mssql.VarChar, report_date)
             .input('sequence2', mssql.VarChar, sequence2)
             .input('sequence_length2', mssql.VarChar, sequence_length2)
             .input('raw_count2', mssql.VarChar, raw_count2)
             .input('v_gene2', mssql.VarChar, v_gene2)
             .input('j_gene2', mssql.VarChar, j_gene2)
             .input('percent_total_reads2', mssql.VarChar, percent_total_reads2)
             .input('cell_equipment2', mssql.VarChar, cell_equipment2);
 
              result = await request.query(qry);
  
            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }

        if (sequence3 != "") {
            //insert Query 생성;
             qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
                sequence, sequence_length, raw_count, \
                v_gene, j_gene, percent_total_reads, \
                cell_equipment) \
                values(@specimenNo, @report_date, 3, \
                @sequence3, @sequence_length3, @raw_count3, \
                @v_gene3, @j_gene3, @percent_total_reads3, \
                @cell_equipment3)";
            
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
            const request = pool.request()
            .input('specimenNo', mssql.VarChar, specimenNo)
            .input('report_date', mssql.VarChar, report_date)
            .input('sequence3', mssql.VarChar, sequence3)
            .input('sequence_length3', mssql.VarChar, sequence_length3)
            .input('raw_count3', mssql.VarChar, raw_count3)
            .input('v_gene3', mssql.VarChar, v_gene3)
            .input('j_gene3', mssql.VarChar, j_gene3)
            .input('percent_total_reads3', mssql.VarChar, percent_total_reads3)
            .input('cell_equipment3', mssql.VarChar, cell_equipment3);

             result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }
        
        if (sequence4 != "") {

            //insert Query 생성;
            qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
               sequence, sequence_length, raw_count, \
               v_gene, j_gene, percent_total_reads, \
               cell_equipment) \
               values(@specimenNo, @report_date, 4, \
               @sequence4, @sequence_length4, @raw_count4, \
               @v_gene4, @j_gene4, @percent_total_reads4, \
               @cell_equipment4)";
           
           logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

           try {
           const request = pool.request()
           .input('specimenNo', mssql.VarChar, specimenNo)
           .input('report_date', mssql.VarChar, report_date)
           .input('sequence4', mssql.VarChar, sequence4)
           .input('sequence_length4', mssql.VarChar, sequence_length4)
           .input('raw_count4', mssql.VarChar, raw_count4)
           .input('v_gene4', mssql.VarChar, v_gene4)
           .input('j_gene4', mssql.VarChar, j_gene4)
           .input('percent_total_reads4', mssql.VarChar, percent_total_reads4)
           .input('cell_equipment4', mssql.VarChar, cell_equipment4);

            result = await request.query(qry);

           } catch (error) {
               logger.error('[80][insertigtcrDataHandler err=' + error.message);
           }
        }
        
        if (sequence5 != "") {

           //insert Query 생성;
           qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
              sequence, sequence_length, raw_count, \
              v_gene, j_gene, percent_total_reads, \
              cell_equipment) \
              values(@specimenNo, @report_date, 5, \
              @sequence5, @sequence_length5, @raw_count5, \
              @v_gene5, @j_gene5, @percent_total_reads5, \
              @cell_equipment5)";
          
          logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

          try {
          const request = pool.request()
          .input('specimenNo', mssql.VarChar, specimenNo)
          .input('report_date', mssql.VarChar, report_date)
          .input('sequence5', mssql.VarChar, sequence5)
          .input('sequence_length5', mssql.VarChar, sequence_length5)
          .input('raw_count5', mssql.VarChar, raw_count5)
          .input('v_gene5', mssql.VarChar, v_gene5)
          .input('j_gene5', mssql.VarChar, j_gene5)
          .input('percent_total_reads5', mssql.VarChar, percent_total_reads5)
          .input('cell_equipment5', mssql.VarChar, cell_equipment5);

           result = await request.query(qry);

          } catch (error) {
              logger.error('[80][insertigtcrDataHandler err=' + error.message);
          }
        }
        
        if (sequence6 != "") {
          //insert Query 생성;
          qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
             sequence, sequence_length, raw_count, \
             v_gene, j_gene, percent_total_reads, \
             cell_equipment) \
             values(@specimenNo, @report_date, 6, \
             @sequence6, @sequence_length6, @raw_count6, \
             @v_gene6, @j_gene6, @percent_total_reads6, \
             @cell_equipment6)";
         
          logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
                const request = pool.request()
                .input('specimenNo', mssql.VarChar, specimenNo)
                .input('report_date', mssql.VarChar, report_date)
                .input('sequence6', mssql.VarChar, sequence6)
                .input('sequence_length6', mssql.VarChar, sequence_length6)
                .input('raw_count6', mssql.VarChar, raw_count6)
                .input('v_gene6', mssql.VarChar, v_gene6)
                .input('j_gene6', mssql.VarChar, j_gene6)
                .input('percent_total_reads6', mssql.VarChar, percent_total_reads6)
                .input('cell_equipment6', mssql.VarChar, cell_equipment6);

                result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }

        if (sequence7 != "") {

         //insert Query 생성;
         qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
            sequence, sequence_length, raw_count, \
            v_gene, j_gene, percent_total_reads, \
            cell_equipment) \
            values(@specimenNo, @report_date, 7, \
            @sequence7, @sequence_length7, @raw_count7, \
            @v_gene7, @j_gene7, @percent_total_reads7, \
            @cell_equipment7)";
        
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
                const request = pool.request()
                .input('specimenNo', mssql.VarChar, specimenNo)
                .input('report_date', mssql.VarChar, report_date)
                .input('sequence7', mssql.VarChar, sequence7)
                .input('sequence_length7', mssql.VarChar, sequence_length7)
                .input('raw_count7', mssql.VarChar, raw_count7)
                .input('v_gene7', mssql.VarChar, v_gene7)
                .input('j_gene7', mssql.VarChar, j_gene7)
                .input('percent_total_reads7', mssql.VarChar, percent_total_reads7)
                .input('cell_equipment7', mssql.VarChar, cell_equipment7);

            result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }
        
        if (sequence8 != "") {
            //insert Query 생성;
            qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
            sequence, sequence_length, raw_count, \
            v_gene, j_gene, percent_total_reads, \
            cell_equipment) \
            values(@specimenNo, @report_date, 8, \
            @sequence8, @sequence_length8, @raw_count8, \
            @v_gene8, @j_gene8, @percent_total_reads8, \
            @cell_equipment8)";
        
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
                const request = pool.request()
                .input('specimenNo', mssql.VarChar, specimenNo)
                .input('report_date', mssql.VarChar, report_date)
                .input('sequence8', mssql.VarChar, sequence8)
                .input('sequence_length8', mssql.VarChar, sequence_length8)
                .input('raw_count8', mssql.VarChar, raw_count8)
                .input('v_gene8', mssql.VarChar, v_gene8)
                .input('j_gene8', mssql.VarChar, j_gene8)
                .input('percent_total_reads8', mssql.VarChar, percent_total_reads8)
                .input('cell_equipment8', mssql.VarChar, cell_equipment8);

                    result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }

        
        if (sequence9 != "") {

            //insert Query 생성;
            qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
                sequence, sequence_length, raw_count, \
                v_gene, j_gene, percent_total_reads, \
                cell_equipment) \
                values(@specimenNo, @report_date, 9, \
                @sequence9, @sequence_length9, @raw_count9, \
                @v_gene9, @j_gene9, @percent_total_reads9, \
                @cell_equipment9)";
            
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
                const request = pool.request()
                .input('specimenNo', mssql.VarChar, specimenNo)
                .input('report_date', mssql.VarChar, report_date)
                .input('sequence9', mssql.VarChar, sequence9)
                .input('sequence_length9', mssql.VarChar, sequence_length9)
                .input('raw_count9', mssql.VarChar, raw_count9)
                .input('v_gene9', mssql.VarChar, v_gene9)
                .input('j_gene9', mssql.VarChar, j_gene9)
                .input('percent_total_reads9', mssql.VarChar, percent_total_reads9)
                .input('cell_equipment9', mssql.VarChar, cell_equipment9);

                result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
        }

        if (sequence10 != "") {
            //insert Query 생성;
            qry = "insert into report_detected_variants_igtcr (specimenNo, report_date, var_idx, \
                sequence, sequence_length, raw_count, \
                v_gene, j_gene, percent_total_reads, \
                cell_equipment) \
                values(@specimenNo, @report_date, 10, \
                @sequence10, @sequence_length10, @raw_count10, \
                @v_gene10, @j_gene10, @percent_total_reads10, \
                @cell_equipment10)";
            
            logger.info('[110][insertigtcrDataHandler detectd_variants messageHandler sql1=' + qry);

            try {
                const request = pool.request()
                .input('specimenNo', mssql.VarChar, specimenNo)
                .input('report_date', mssql.VarChar, report_date)
                .input('sequence10', mssql.VarChar, sequence10)
                .input('sequence_length10', mssql.VarChar, sequence_length10)
                .input('raw_count10', mssql.VarChar, raw_count10)
                .input('v_gene10', mssql.VarChar, v_gene10)
                .input('j_gene10', mssql.VarChar, j_gene10)
                .input('percent_total_reads10', mssql.VarChar, percent_total_reads10)
                .input('cell_equipment10', mssql.VarChar, cell_equipment10);

                result = await request.query(qry);

            } catch (error) {
                logger.error('[80][insertigtcrDataHandler err=' + error.message);
            }
    }
          
          //return result;

    }
}

// igtcr DATA 삭제
const deleteigtcrDataHandler = async (specimenNo) => {
    await poolConnect;

    logger.info('[38][deleteigtcrDataHandler]delete igtcrData] specimenNo=' + specimenNo);
    //delete Query 생성;    
    const qry ="delete report_detected_igtcr where specimenNo=@specimenNo";           
    logger.info("[41][deleteMigtcrDataHandler][del igtcr Data]del sql=" + qry);
  
    try {
        const request = pool.request()
          .input('specimenNo', mssql.VarChar, specimenNo);
          result = await request.query(qry);          
    } catch (error) {
      logger.error('[48][deleteigtcrDataHandler][del igtcr Data]err=' +  error.message);
    }
      
    return result;
};

// igtcr DATA 삭제
const deleteigtcrHandler = async (specimenNo) => {
    await poolConnect;

    logger.info('[38][deleteigtcrHandler]delete igtcrData] specimenNo=' + specimenNo);
    //delete Query 생성;    
    const qry ="delete report_detected_variants_igtcr where specimenNo=@specimenNo";           
    logger.info("[41][deleteigtcrHandler][del igtcr Data]del sql=" + qry);
  
    try {
        const request = pool.request()
          .input('specimenNo', mssql.VarChar, specimenNo);
          result = await request.query(qry);          
    } catch (error) {
      logger.error('[48][deleteigtcrHandler][del igtcr Data]err=' +  error.message);
    }
      
    return result;
};

exports.saveScreenigtcr = (req,res, next) => {
    logger.info('[149][MLPA][saveScreenigtcr]req=' + JSON.stringify(req.body));
    
    const specimenNo        = req.body.specimenNo;
    
    let method = req.body.method;

    let igtcrData = req.body.data;
 
    let examin    = req.body.examin;
    let recheck   = req.body.recheck;
    let sendEMRDate   = req.body.sendEMRDate;
    let report_date   = req.body.report_date;
    let comment   = req.body.comment;

    logger.info('[169][igtcr][saveScreenigtcr]specimenNo=, ' + specimenNo); 

    const igtcrDataDel = deleteigtcrDataHandler(specimenNo);
    igtcrDataDel.then(data => {

        const igtcrDel = deleteigtcrHandler(specimenNo);
        igtcrDel.then(data => {

            const  igtcrDataInsert = insertigtcrDataHandler(specimenNo, igtcrData);
            igtcrDataInsert.then(data => {
                // 검사지 변경
                const check = checkerHandler(specimenNo,  examin, recheck, method, sendEMRDate, report_date, comment);
                check.then(data => {
                    res.json({message: 'OK'});
                });
            })
            .catch( error  => {
            logger.error('[185][screenList][saveScreenigtcr]err=' + error.message);
            res.sendStatus(500)
            });
        });
    });
   
}

