
 module.exports = {
    cdw_path_diag: 'C:\\NGS_LAB\\' ,
    cdw_path_path: 'C:\\NGS_PATH\\',
    emr_path: 'http://emr012edu.cmcnu.or.kr/cmcnu/.live',
 
};