

 const krgdb_module = require('./krgdb');

 const result = krgdb_module.krgdb('','');
 console.log(result);
 


  
 

 
 